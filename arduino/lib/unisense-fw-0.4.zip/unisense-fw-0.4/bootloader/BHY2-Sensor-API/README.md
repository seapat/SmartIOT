# BHI260AB/BHA260AB Sensor API

> This package contains BHI260AB/BHA260AB generically clustered as BHy2 sensor API

Product links
- [BHA260AB](https://www.bosch-sensortec.com/products/smart-sensors/bha260ab.html)
- [BHI260AB](https://www.bosch-sensortec.com/products/smart-sensors/bhi260ab.html)

---
#### Copyright (C) 2020 Bosch Sensortec GmbH. All rights reserved
